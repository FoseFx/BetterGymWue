"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CONFIG = {
    navbarURL: "http://gymnasium-wuerselen.de/untis/Schueler-Stundenplan/frames/navbar.htm"
};
//# sourceMappingURL=CONFIG.js.map