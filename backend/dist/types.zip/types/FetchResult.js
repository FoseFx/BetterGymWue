"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class FetchResult {
}
exports.FetchResult = FetchResult;
//# sourceMappingURL=FetchResult.js.map